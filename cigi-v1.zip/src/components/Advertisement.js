import React from 'react';

function Advertisement(){
    return(
     <section>
<div className="Ad"></div>


<div className="b">This div element has position: absolute and left: auto.</div>

<div className="a">This div element has position: absolute and right: auto.</div>
     </section>

    );
}

export default Advertisement;