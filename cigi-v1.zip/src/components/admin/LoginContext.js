import {createContext} from 'react';
const LoginContext=createContext(false);
export default LoginContext;