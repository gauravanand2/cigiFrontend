export const COLUMNS=[
    
    {
        Header:'CID',
        accessor:'id'
    },
    {
        Header:'Name',
        accessor:'name'
    },
    {
        Header:'Link',
        accessor:'link'
    },
    {
        Header:'Language',
        accessor:'language'
    },
    {
        Header:'Year',
        accessor:'year'
    }
]